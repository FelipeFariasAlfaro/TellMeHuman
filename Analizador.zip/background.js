/*function isAllowedUrl(url) {
  try {
    if (!url) return false;
    const u = new URL(url);
    return ['http:', 'https:'].includes(u.protocol);
  } catch (e) {
    return false;
  }
}

// On installed: crear context menu y (opcional) establecer opciones por defecto
chrome.runtime.onInstalled.addListener(() => {
  try {
    chrome.contextMenus.create({
      id: "analyze-selection",
      title: "Analizar",
      contexts: ["selection"]
    });
    chrome.contextMenus.create({
      id: "pertinence-selection",
      title: "Pertinencia",
      contexts: ["selection"]
    });
    chrome.sidePanel.setOptions?.({ path: "sidepanel.html", enabled: true });
    chrome.sidePanel.setPanelBehavior?.({ openPanelOnActionClick: true });
  } catch (e) {
    console.warn("onInstalled:", e);
  }
});

// Almacena una referencia al puerto de conexión para saber si el sidepanel está abierto.
let sidepanelPort = null;

// Escuchar la conexión del sidepanel
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'sidepanel_ready') {
    sidepanelPort = port;
    console.log("Sidepanel conectado y listo.");

    // Escuchar la desconexión del sidepanel (cuando se cierra)
    //port.onDisconnect.addListener(() => {
      //sidepanelPort = null;
      //console.log("Sidepanel desconectado.");
    //});
  }
});

// Función del menú contextual
chrome.contextMenus.onClicked.addListener((info, tab) => {

  const selectionFromInfo = info.selectionText?.trim();
  const messagePayload1 = { type: "envio_texto", payload: selectionFromInfo };
  const messagePayload2 = { type: "envio_texto_pertinencia", payload: selectionFromInfo };
  const panelState = chrome.sidePanel.getOptions({ tabId: tab.id });

  if (info.menuItemId === "analyze-selection") {
    
    // Si el sidepanel ya está abierto, enviar el mensaje a través del port
    if (panelState?.enabled) {
      sidepanelPort.postMessage(messagePayload1);
    } else {
      chrome.storage.sync.set({ textfromhtml: selectionFromInfo });
      chrome.sidePanel.open({ tabId: tab.id });
      try{
        sidepanelPort.postMessage(messagePayload1);
      }catch(e){
        //try de control
      }
    }

  }
  else if (info.menuItemId === "pertinence-selection") {
    if (panelState?.enabled) {
      sidepanelPort.postMessage(messagePayload2);
    } else {
      chrome.storage.sync.set({ textpertinencefromhtml: selectionFromInfo });
      chrome.sidePanel.open({ tabId: tab.id });
      try{
        sidepanelPort.postMessage(messagePayload2);
      }catch(e){
        console.log("Error.",e);
      }
    }

  }
});


// Opcional: cuando el user hace click en el icono (action), abrimos el sidepanel inmediato
chrome.action.onClicked.addListener((tab) => {
  try {
    if (!tab || !tab.id || !isAllowedUrl(tab.url)) {
      console.warn("No hay pestaña válida para abrir sidePanel.");
      return;
    }
    // abrir inmediatamente (no await)
    chrome.sidePanel.open({ tabId: tab.id }).catch(err => {
      console.error("Error abriendo sidePanel (action):", err);
    });
    chrome.sidePanel.setOptions({ tabId: tab.id, path: "sidepanel.html", enabled: true }).catch(() => { });
  } catch (e) {
    console.error("action.onClicked error:", e);
  }
});*/

// background.js — Gestión robusta del sidepanel y mensajes desde context menu
// -------------------------------------------------------------
// Notas:
// - No usamos await antes de chrome.sidePanel.open(...) en handlers de gesto usuario.
// - Mapeamos puertos por tabId y encolamos mensajes si el sidepanel aún no está conectado.
// - Si el sidepanel se conecta sin sender.tab.id, usamos expectedTabForNextPort para asignarlo.
// -------------------------------------------------------------

/* eslint-disable no-console */

// Utilidad: validar URL
function isAllowedUrl(url) {
  try {
    if (!url) return false;
    const u = new URL(url);
    return ['http:', 'https:'].includes(u.protocol);
  } catch (e) {
    return false;
  }
}

// ON INSTALLED: crear menus y opciones por defecto
chrome.runtime.onInstalled.addListener(() => {
  try {
    chrome.contextMenus.create({
      id: "analyze-selection",
      title: "Analizar",
      contexts: ["selection"]
    });
    chrome.contextMenus.create({
      id: "pertinence-selection",
      title: "Pertinencia",
      contexts: ["selection"]
    });

    // establecer sidepanel globalmente si API disponible
    if (chrome.sidePanel?.setOptions) {
      chrome.sidePanel.setOptions({ path: "sidepanel.html", enabled: true });
    }
    // comportamiento opcional
    if (chrome.sidePanel?.setPanelBehavior) {
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    }

    console.log("onInstalled: context menus y sidepanel configurados.");
  } catch (e) {
    console.warn("onInstalled error:", e);
  }
});

// ======== Estado y colas ========
// Mapa de puertos por tabId: sidepanelPorts[tabId] = port
const sidepanelPorts = {};

// Mensajes pendientes por tabId: pendingMessages[tabId] = [msg,...]
const pendingMessages = {};

// Si abrimos el sidepanel programáticamente, guardamos para qué tabId esperamos el próximo port
let expectedTabForNextPort = null;

// Marcar que esperamos que el próximo port corresponda a tabId
function markExpectedPortFor(tabId) {
  expectedTabForNextPort = tabId;
  // Timeout de seguridad: limpiar la expectativa si no llega en 10s
  setTimeout(() => {
    if (expectedTabForNextPort === tabId) expectedTabForNextPort = null;
  }, 10000);
}

// Encolar o enviar inmediatamente
function sendOrQueue(tabId, payload) {
  if (!tabId) {
    console.warn("sendOrQueue recibió tabId inválido:", tabId, payload);
    return;
  }
  const port = sidepanelPorts[tabId];
  if (port) {
    try {
      port.postMessage(payload);
      console.log("Mensaje enviado directo a sidepanel (tab):", tabId, payload);
    } catch (e) {
      console.warn("postMessage falló, encolando:", e);
      pendingMessages[tabId] = pendingMessages[tabId] || [];
      pendingMessages[tabId].push(payload);
    }
  } else {
    pendingMessages[tabId] = pendingMessages[tabId] || [];
    pendingMessages[tabId].push(payload);
    console.log("Sidepanel no conectado todavía — mensaje encolado para tab", tabId, payload);
  }
}

// ======== Listener de conexiones desde sidepanel ========
chrome.runtime.onConnect.addListener((port) => {
  try {
    if (port.name !== 'sidepanel_ready') {
      // ignorar otros puertos
      return;
    }

    console.log("onConnect: sidepanel se conectó. port.sender:", port.sender);

    // Intentar extraer tabId desde sender (puede ser undefined)
    let tabId = port.sender?.tab?.id ?? null;

    // Si no hay tabId pero tenemos una expectativa, asignamos
    if (tabId === null && expectedTabForNextPort !== null) {
      tabId = expectedTabForNextPort;
      expectedTabForNextPort = null;
      console.log("Asignando port del sidepanel a tabId esperado:", tabId);
    }

    if (tabId === null) {
      // No sabemos la tab: lo guardamos con clave temporal para no perder el port
      const unknownKey = `unknown_${Date.now()}`;
      sidepanelPorts[unknownKey] = port;
      console.warn("Sidepanel conectado sin tabId conocido. Guardado como:", unknownKey);
      // No enviamos pendientes porque no sabemos a qué tab pertenecen
    } else {
      // Guardar puerto por tabId
      sidepanelPorts[tabId] = port;
      console.log("Sidepanel conectado y mapeado a tabId:", tabId);

      // Despachar cola pendiente si existe
      const queue = pendingMessages[tabId];
      if (Array.isArray(queue) && queue.length) {
        console.log("Enviando mensajes pendientes a tab", tabId, queue.length);
        queue.forEach(msg => {
          try {
            port.postMessage(msg);
          } catch (e) {
            console.warn("Envio de mensaje pendiente fallo:", e);
          }
        });
        delete pendingMessages[tabId];
      }
    }

    // Limpiar al desconectar
    port.onDisconnect.addListener(() => {
      // Encontrar la clave asociada a este port y eliminarla
      for (const key of Object.keys(sidepanelPorts)) {
        if (sidepanelPorts[key] === port) {
          delete sidepanelPorts[key];
          console.log("Sidepanel disconnected; clave removida:", key);
        }
      }
    });

  } catch (e) {
    console.error("onConnect error:", e);
  }
});

// ======== Handler del menú contextual ========
chrome.contextMenus.onClicked.addListener((info, tab) => {
  try {
    if (!tab || !tab.id || !isAllowedUrl(tab.url)) {
      console.warn("contextMenus.onClicked: pestaña inválida o URL no permitida.", tab);
      return;
    }

    const selection = info.selectionText?.trim() ?? "";

    if (info.menuItemId === "analyze-selection") {
      const payload = { type: "envio_texto", payload: selection };
      // Guardar en storage por si el sidepanel se inicializa leyendo storage
      chrome.storage.sync.set({ textfromhtml: selection }, () => {
        // Marcar expectativa para la próxima conexión del sidepanel
        markExpectedPortFor(tab.id);

        // Abrir sidepanel SIN await para preservar cadena de gesto usuario
        chrome.sidePanel.open({ tabId: tab.id }).catch(err => {
          console.error("Error abriendo sidePanel (analyze-selection):", err);
        });

        // Enviar o encolar el mensaje
        sendOrQueue(tab.id, payload);
      });

    } else if (info.menuItemId === "pertinence-selection") {
      const payload = { type: "envio_texto_pertinencia", payload: selection };
      chrome.storage.sync.set({ textpertinencefromhtml: selection }, () => {
        markExpectedPortFor(tab.id);
        chrome.sidePanel.open({ tabId: tab.id }).catch(err => {
          console.error("Error abriendo sidePanel (pertinence-selection):", err);
        });
        sendOrQueue(tab.id, payload);
      });

    } else {
      console.warn("contextMenus.onClicked: menuItemId no reconocido:", info.menuItemId);
    }
  } catch (e) {
    console.error("contextMenus.onClicked error:", e);
  }
});

// ======== action.onClicked: abrir sidepanel desde el icono ========
chrome.action.onClicked.addListener((tab) => {
  try {
    if (!tab || !tab.id || !isAllowedUrl(tab.url)) {
      console.warn("No hay pestaña válida para abrir sidePanel (action).");
      return;
    }
    // Marcar expectativa por si hacemos envíos después de abrir
    markExpectedPortFor(tab.id);
    chrome.sidePanel.open({ tabId: tab.id }).catch(err => {
      console.error("Error abriendo sidePanel (action):", err);
    });

    // Asegurar opciones por tab si API lo permite
    if (chrome.sidePanel?.setOptions) {
      chrome.sidePanel.setOptions({ tabId: tab.id, path: "sidepanel.html", enabled: true }).catch(() => { });
    }

  } catch (e) {
    console.error("action.onClicked error:", e);
  }
});

// ======== (Opcional) Exponer helper para debugging desde popup o devtools ========
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg === 'debug_get_state') {
    sendResponse({
      sidepanelPortsKeys: Object.keys(sidepanelPorts),
      pendingMessagesKeys: Object.keys(pendingMessages),
      expectedTabForNextPort
    });
  }
  // Si quieres más comandos de debug, agrégalos aquí
});
